
public class Constants {
	public static final int ROBOT_LISTEN = 1210;
	public static final int BOOSTRAP_LISTEN = 1215;
	public static final String BOOTSTRAP_HOST = "glados.cs.rit.edu";
	//public static final String ROBOT_HOST="localhost";
}
